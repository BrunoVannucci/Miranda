import React from "react";
import Mic from "../mic/Mic";
import imgAbertura from "../../Abertura.png";

const Home = () => {
  return (
    <div>
      <img id='imgAbertura' src={imgAbertura} alt='Miranda' />

      <Mic />
    </div>
  );
};

export default Home;
