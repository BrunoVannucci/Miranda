import React from "react";
import MicRecorder from "mic-recorder-to-mp3";
import foto from "../../foto.jpeg";
//import axios from "axios";

const Mp3Recorder = new MicRecorder({ bitRate: 128 });

//const formData = new FormData();

class Mic extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isRecording: false,
      blobURL: "",
      isBlocked: false,
    };
  }

  start = () => {
    if (this.state.isBlocked) {
      console.log("Permission Denied");
    } else {
      Mp3Recorder.start()
        .then(() => {
          this.setState({ isRecording: true });
        })
        .catch((e) => console.error(e));
    }
  };

  stop = () => {
    Mp3Recorder.stop()
      .getMp3()
      .then(([buffer, blob]) => {
        const blobURL = URL.createObjectURL(blob);
        this.setState({ blobURL, isRecording: false });
        uploadDocumentRequest(blob);
      })

      .catch((e) => console.log(e));
  };

  componentDidMount() {
    navigator.getUserMedia(
      { audio: true },
      () => {
        console.log("Permission Granted");
        this.setState({ isBlocked: false });
      },
      () => {
        console.log("Permission Denied");
        this.setState({ isBlocked: true });
      }
    );
  }

  render() {
    return (
      <div className='Mic'>
        <button onClick={this.start} disabled={this.state.isRecording}>
          Grava
        </button>
        <button onClick={this.stop} disabled={!this.state.isRecording}>
          Envia
        </button>
      </div>
    );
  }
}
//<audio src={this.state.blobURL} controls='controls' />

export default Mic;

export function uploadDocumentRequest(data) {
  /*axios
    .post("https://miranda-app-280116.uc.r.appspot.com/api/check", data)
    .then((response) => console.log("uploadSuccess(response)"))
    .catch((error) => console.log("uploadFail(error)"));*/

  var fd = new FormData();
  fd.append("audio_data", data);

  fetch("https://miranda-app-280116.uc.r.appspot.com/miranda/audio", {
    headers: { Accept: "application/json" },
    method: "POST",
    mode: "no-cors",
    body: fd,
  });

  var fd2 = new FormData();
  //let file = '../..';
  fd2.append("image_data", foto);

  fetch("https://miranda-app-280116.uc.r.appspot.com/miranda/imagem", {
    method: "POST",
    mode: "no-cors",
    body: fd2,
  });
}
